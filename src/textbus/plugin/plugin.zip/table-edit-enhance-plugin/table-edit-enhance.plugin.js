var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
import { CubicBezier } from '@tanbo/bezier';
import { Inject, Injectable, Renderer, TBRange, TBSelection, BrComponent, EDITABLE_DOCUMENT, Layout } from '@textbus/core';
import { TableComponent } from '@textbus/components';
function findParentByTagName(node, tagNames) {
    if (node.nodeType === Node.TEXT_NODE) {
        return findParentByTagName(node.parentNode, tagNames);
    }
    const regs = tagNames.map(tagName => new RegExp(`^${tagName}$`, 'i'));
    if (node.nodeType === Node.ELEMENT_NODE) {
        if (regs.map(reg => reg.test(node.nodeName)).indexOf(true) > -1) {
            return node;
        }
        return findParentByTagName(node.parentNode, tagNames);
    }
    return null;
}
let TableEditEnhancePlugin = class TableEditEnhancePlugin {
    constructor(contentDocument, layout, renderer, selection) {
        this.contentDocument = contentDocument;
        this.layout = layout;
        this.renderer = renderer;
        this.selection = selection;
        this.mask = document.createElement('div');
        this.firstMask = document.createElement('div');
        this.insertMask = false;
        this.insertStyle = false;
        this.selectedCells = [];
        this.animateBezier = new CubicBezier(0.25, 0.1, 0.25, 0.1);
        this.inTable = true;
        this.subs = [];
        this.subs.push(this.selection.onChange.subscribe(() => {
            this.onSelectionChange();
        }), this.renderer.onViewUpdated.subscribe(() => {
            this.onViewUpdated();
        }));
    }
    setup() {
        this.mask.classList.add('textbus-table-editor-plugin-mask');
        this.firstMask.classList.add('textbus-table-editor-plugin-first-cell');
        this.mask.appendChild(this.firstMask);
        const style = this.contentDocument.createElement('style');
        this.styleElement = style;
        style.innerText = '::selection { background: transparent; }';
    }
    onDestroy() {
        this.subs.forEach(i => i.unsubscribe());
    }
    onSelectionChange() {
        var _a;
        this.inTable = false;
        this.startCell = null;
        this.endCell = null;
        this.tableElement = null;
        this.selectedCells = [];
        let tableComponent;
        const commonAncestorComponent = this.selection.commonAncestorComponent;
        if (commonAncestorComponent instanceof TableComponent) {
            tableComponent = commonAncestorComponent;
        }
        else {
            tableComponent = (_a = commonAncestorComponent === null || commonAncestorComponent === void 0 ? void 0 : commonAncestorComponent.parentFragment) === null || _a === void 0 ? void 0 : _a.getContext(TableComponent);
        }
        if (!tableComponent) {
            this.showNativeSelectionMask();
            this.removeMask();
            return;
        }
        this.tableComponent = tableComponent;
        const nativeSelection = this.contentDocument.getSelection();
        if (nativeSelection.rangeCount === 0) {
            return;
        }
        this.startCell = findParentByTagName(nativeSelection.anchorNode, ['th', 'td']);
        this.endCell = findParentByTagName(nativeSelection.focusNode, ['th', 'td']);
        this.tableElement = findParentByTagName(nativeSelection.anchorNode, ['table']);
        if (this.startCell === this.endCell) {
            this.showNativeSelectionMask();
        }
        else {
            this.hideNativeSelectionMask();
        }
        this.inTable = true;
        this.setSelectedCellsAndUpdateMaskStyle();
        if (this.selectedCells.length) {
            if (this.selectedCells.length === 1) {
                return;
            }
            this.selection.removeAllRanges();
            this.selectedCells.map(cell => {
                const range = new TBRange(this.contentDocument.createRange(), this.renderer);
                const firstContent = cell.getContentAtIndex(0);
                if (cell.length === 1 && firstContent instanceof BrComponent) {
                    range.setStart(cell, 0);
                    range.setEnd(cell, 1);
                }
                else {
                    const startPosition = range.findFirstPosition(cell);
                    const endPosition = range.findLastChild(cell);
                    range.setStart(startPosition.fragment, startPosition.index);
                    range.setEnd(endPosition.fragment, endPosition.index);
                }
                this.selection.addRange(range);
            });
        }
    }
    onViewUpdated() {
        if (this.startPosition && this.endPosition && this.tableComponent) {
            this.startCell = this.renderer.getNativeNodeByVDom(this.renderer.getVElementByFragment(this.startPosition.cell.fragment));
            this.endCell = this.renderer.getNativeNodeByVDom(this.renderer.getVElementByFragment(this.endPosition.cell.fragment));
            if (this.startCell && this.endCell && this.inTable) {
                this.setSelectedCellsAndUpdateMaskStyle();
            }
            else {
                this.removeMask();
                this.showNativeSelectionMask();
            }
        }
    }
    hideNativeSelectionMask() {
        if (!this.insertStyle) {
            this.contentDocument.head.appendChild(this.styleElement);
            this.insertStyle = true;
        }
    }
    showNativeSelectionMask() {
        var _a;
        this.insertStyle = false;
        (_a = this.styleElement.parentNode) === null || _a === void 0 ? void 0 : _a.removeChild(this.styleElement);
    }
    removeMask() {
        var _a;
        this.insertMask = false;
        (_a = this.mask.parentNode) === null || _a === void 0 ? void 0 : _a.removeChild(this.mask);
    }
    addMask() {
        this.layout.docContainer.appendChild(this.mask);
        this.insertMask = true;
    }
    setSelectedCellsAndUpdateMaskStyle(animate = true) {
        const { startPosition, endPosition, selectedCells } = this.tableComponent.selectCells(this.selection);
        const startRect = this.renderer.getNativeNodeByVDom(this.renderer.getVElementByFragment(startPosition.cell.fragment)).getBoundingClientRect();
        const endRect = this.renderer.getNativeNodeByVDom(this.renderer.getVElementByFragment(endPosition.cell.fragment)).getBoundingClientRect();
        const firstCellRect = this.startCell.getBoundingClientRect();
        this.firstMask.style.width = firstCellRect.width + 'px';
        this.firstMask.style.height = firstCellRect.height + 'px';
        if (animate && this.insertMask) {
            this.animate({
                left: this.mask.offsetLeft,
                top: this.mask.offsetTop,
                width: this.mask.offsetWidth,
                height: this.mask.offsetHeight
            }, {
                left: startRect.left,
                top: startRect.top,
                width: endRect.right - startRect.left,
                height: endRect.bottom - startRect.top
            }, {
                left: firstCellRect.left - startRect.left,
                top: firstCellRect.top - startRect.top,
                width: firstCellRect.width,
                height: firstCellRect.height
            });
        }
        else {
            this.addMask();
            this.mask.style.left = startRect.left + 'px';
            this.mask.style.top = startRect.top + 'px';
            this.mask.style.width = endRect.right - startRect.left + 'px';
            this.mask.style.height = endRect.bottom - startRect.top + 'px';
            this.firstMask.style.left = firstCellRect.left - startRect.left + 'px';
            this.firstMask.style.top = firstCellRect.top - startRect.top + 'px';
        }
        this.startPosition = startPosition;
        this.endPosition = endPosition;
        this.selectedCells = selectedCells;
    }
    animate(start, target, firstCellPosition) {
        cancelAnimationFrame(this.animateId);
        function toInt(n) {
            return n < 0 ? Math.ceil(n) : Math.floor(n);
        }
        let step = 0;
        const maxStep = 6;
        const animate = () => {
            step++;
            const ratio = this.animateBezier.update(step / maxStep).y;
            const left = start.left + toInt((target.left - start.left) * ratio);
            const top = start.top + toInt((target.top - start.top) * ratio);
            const width = start.width + toInt((target.width - start.width) * ratio);
            const height = start.height + toInt((target.height - start.height) * ratio);
            this.mask.style.left = left + 'px';
            this.mask.style.top = top + 'px';
            this.mask.style.width = width + 'px';
            this.mask.style.height = height + 'px';
            this.firstMask.style.left = target.left - left + firstCellPosition.left + 'px';
            this.firstMask.style.top = target.top - top + firstCellPosition.top + 'px';
            if (step < maxStep) {
                this.animateId = requestAnimationFrame(animate);
            }
        };
        this.animateId = requestAnimationFrame(animate);
    }
};
TableEditEnhancePlugin = __decorate([
    Injectable(),
    __param(0, Inject(EDITABLE_DOCUMENT)),
    __metadata("design:paramtypes", [Document,
        Layout,
        Renderer,
        TBSelection])
], TableEditEnhancePlugin);
export { TableEditEnhancePlugin };
//# sourceMappingURL=table-edit-enhance.plugin.js.map