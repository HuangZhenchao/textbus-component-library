import { Renderer, TBSelection } from '@textbus/core';
import {TBPlugin} from '@textbus/browser'
import {I18n,Layout} from '@textbus/editor'
export declare class TableEditEnhancePlugin implements TBPlugin {
    private contentDocument;
    private layout;
    private renderer;
    private selection;
    private mask;
    private firstMask;
    private insertMask;
    private insertStyle;
    private styleElement;
    private selectedCells;
    private startPosition;
    private endPosition;
    private tableElement;
    private startCell;
    private endCell;
    private animateBezier;
    private animateId;
    private tableComponent;
    private inTable;
    private subs;
    constructor(contentDocument: Document, layout: Layout, renderer: Renderer, selection: TBSelection);
    setup(): void;
    onDestroy(): void;
    private onSelectionChange;
    private onViewUpdated;
    private hideNativeSelectionMask;
    private showNativeSelectionMask;
    private removeMask;
    private addMask;
    private setSelectedCellsAndUpdateMaskStyle;
    private animate;
}
