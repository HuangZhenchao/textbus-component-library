import { Renderer, TBSelection,  } from '@textbus/core';
import { TBPlugin } from '@textbus/browser';
import { Layout } from '@textbus/editor';
export declare class ImageAndVideoDragResizePlugin implements TBPlugin {
    private contentDocument;
    private layout;
    private renderer;
    private selection;
    private mask;
    private text;
    private handlers;
    private currentComponent;
    private currentElement;
    private subs;
    constructor(contentDocument: Document, layout: Layout, renderer: Renderer, selection: TBSelection);
    setup(): void;
    onDestroy(): void;
    private init;
    private onViewUpdated;
    private onSelectionChange;
    private updateStyle;
}
