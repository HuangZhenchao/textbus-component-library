var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
import { Inject, Injectable, Renderer, TBSelection, EDITABLE_DOCUMENT, Layout } from '@textbus/core';
function matchAngle(x, y, startAngle, endAngle) {
    let angle = Math.atan(x / y) / (Math.PI / 180);
    if (x <= 0 && y >= 0 || x >= 0 && y >= 0) {
        angle = 180 + angle;
    }
    if (x >= 0 && y <= 0) {
        angle = 360 + angle;
    }
    if (startAngle <= endAngle) {
        return angle >= startAngle && angle <= endAngle;
    }
    return angle >= startAngle && angle <= 360 || angle <= endAngle && angle <= 0;
}
let ImageAndVideoDragResizePlugin = class ImageAndVideoDragResizePlugin {
    constructor(contentDocument, layout, renderer, selection) {
        this.contentDocument = contentDocument;
        this.layout = layout;
        this.renderer = renderer;
        this.selection = selection;
        this.mask = document.createElement('div');
        this.text = document.createElement('div');
        this.handlers = [];
        this.subs = [];
        this.subs.push(this.renderer.onViewUpdated.subscribe(() => {
            this.onViewUpdated();
        }), this.selection.onChange.subscribe(() => {
            this.onSelectionChange();
        }));
    }
    setup() {
        this.mask.className = 'textbus-image-video-resize-plugin-handler';
        for (let i = 0; i < 8; i++) {
            const button = document.createElement('button');
            button.type = 'button';
            this.handlers.push(button);
        }
        this.mask.append(...this.handlers);
        this.mask.append(this.text);
        this.mask.addEventListener('mousedown', ev => {
            if (!this.currentComponent) {
                return;
            }
            this.layout.docContainer.style.pointerEvents = 'none';
            const startRect = this.currentElement.getBoundingClientRect();
            this.currentComponent.width = startRect.width + 'px';
            this.currentComponent.height = startRect.height + 'px';
            const startX = ev.clientX;
            const startY = ev.clientY;
            const startWidth = startRect.width;
            const startHeight = startRect.height;
            const startHypotenuse = Math.sqrt(startWidth * startWidth + startHeight * startHeight);
            let endWidth = startWidth;
            let endHeight = startHeight;
            const index = this.handlers.indexOf(ev.target);
            const mouseMoveFn = (ev) => {
                const moveX = ev.clientX;
                const moveY = ev.clientY;
                const offsetX = moveX - startX;
                const offsetY = moveY - startY;
                if ([0, 2, 4, 6].includes(index)) {
                    const gainHypotenuse = Math.sqrt(offsetX * offsetX + offsetY * offsetY);
                    let proportion = gainHypotenuse / startHypotenuse;
                    if (!(index === 0 && matchAngle(offsetX, offsetY, 315, 135) ||
                        index === 2 && matchAngle(offsetX, offsetY, 225, 45) ||
                        index === 4 && matchAngle(offsetX, offsetY, 135, 315) ||
                        index === 6 && matchAngle(offsetX, offsetY, 45, 225))) {
                        proportion = -proportion;
                    }
                    endWidth = Math.round(startWidth + startWidth * proportion);
                    endHeight = Math.round(startHeight + startHeight * proportion);
                }
                else if ([1, 5].includes(index)) {
                    endHeight = Math.round(startHeight + (index === 1 ? -offsetY : offsetY));
                }
                else if ([3, 7].includes(index)) {
                    endWidth = Math.round(startWidth + (index === 3 ? offsetX : -offsetX));
                }
                this.currentElement.style.width = endWidth + 'px';
                this.currentElement.style.height = endHeight + 'px';
                this.updateStyle();
            };
            const mouseUpFn = () => {
                this.currentComponent.width = endWidth + 'px';
                this.currentComponent.height = endHeight + 'px';
                this.layout.docContainer.style.pointerEvents = '';
                if (this.renderer) {
                    const vEle = this.renderer.getVDomByNativeNode(this.currentElement);
                    vEle.styles.set('width', endWidth + 'px');
                    vEle.styles.set('height', endHeight + 'px');
                }
                this.currentComponent.markAsDirtied();
                document.removeEventListener('mousemove', mouseMoveFn);
                document.removeEventListener('mouseup', mouseUpFn);
            };
            document.addEventListener('mousemove', mouseMoveFn);
            document.addEventListener('mouseup', mouseUpFn);
        });
        this.init();
    }
    onDestroy() {
        this.subs.forEach(i => i.unsubscribe());
    }
    init() {
        const renderer = this.renderer;
        const contextDocument = this.contentDocument;
        contextDocument.addEventListener('click', ev => {
            const srcElement = ev.target;
            if (/^img$|video/i.test(srcElement.nodeName)) {
                const position = renderer.getPositionByNode(srcElement);
                if (!position) {
                    return;
                }
                this.currentElement = srcElement;
                this.currentComponent = position.fragment.getContentAtIndex(position.startIndex);
                const selection = contextDocument.getSelection();
                this.selection.removeAllRanges(true);
                const range = contextDocument.createRange();
                range.selectNode(srcElement);
                selection.addRange(range);
                this.updateStyle();
                this.layout.docContainer.append(this.mask);
            }
            else {
                this.currentElement = null;
                this.currentComponent = null;
                if (this.mask.parentNode) {
                    this.mask.parentNode.removeChild(this.mask);
                }
            }
        });
    }
    onViewUpdated() {
        var _a, _b;
        if ((_a = this.currentElement) === null || _a === void 0 ? void 0 : _a.parentNode) {
            this.updateStyle();
        }
        else {
            this.currentElement = null;
            (_b = this.mask.parentNode) === null || _b === void 0 ? void 0 : _b.removeChild(this.mask);
        }
    }
    onSelectionChange() {
        var _a;
        if (this.selection.collapsed) {
            this.currentElement = null;
            (_a = this.mask.parentNode) === null || _a === void 0 ? void 0 : _a.removeChild(this.mask);
        }
    }
    updateStyle() {
        const rect = this.currentElement.getBoundingClientRect();
        this.mask.style.cssText = `left: ${rect.left}px; top: ${rect.top}px; width: ${rect.width}px; height: ${rect.height}px;`;
        this.text.innerText = `${Math.round(rect.width)}px * ${Math.round(rect.height)}px`;
    }
};
ImageAndVideoDragResizePlugin = __decorate([
    Injectable(),
    __param(0, Inject(EDITABLE_DOCUMENT)),
    __metadata("design:paramtypes", [Document,
        Layout,
        Renderer,
        TBSelection])
], ImageAndVideoDragResizePlugin);
export { ImageAndVideoDragResizePlugin };
//# sourceMappingURL=image-and-video-drag-resize.plugin.js.map