var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { fromEvent } from 'rxjs';
import { distinctUntilChanged, map, tap } from 'rxjs/operators';
import pretty from 'pretty';
import codemirror from 'codemirror';
import 'codemirror/mode/htmlmixed/htmlmixed';
import { Injectable, EditorController, Editor, Layout, createElement, I18n, createTextNode } from '@textbus/core';
let SourcecodeModePlugin = class SourcecodeModePlugin {
    constructor(layout, editor, i18n, editorController) {
        this.layout = layout;
        this.editor = editor;
        this.i18n = i18n;
        this.editorController = editorController;
        this.subs = [];
        this.container = createElement('div', {
            classes: ['textbus-sourcecode-mode-plugin-container']
        });
    }
    setup() {
        const el = createElement('div', {
            classes: [],
            children: [
                this.btn = createElement('button', {
                    classes: ['textbus-status-bar-btn'],
                    attrs: {
                        type: 'button'
                    },
                    children: [createTextNode(this.i18n.get('plugins.sourcecodeMode.switchText') || '源代码')]
                })
            ]
        });
        this.layout.bottomBar.appendChild(el);
        this.layout.workbench.appendChild(this.container);
        this.subs.push(fromEvent(this.btn, 'click').subscribe(() => {
            this.editorController.sourceCodeMode = !this.editorController.sourceCodeMode;
        }), this.editorController.onStateChange.pipe(tap(status => {
            this.btn.disabled = status.readonly;
            if (this.codeMirrorInstance) {
                this.codeMirrorInstance.setOption('readOnly', this.editorController.readonly ? 'nocursor' : false);
            }
        }), map(status => {
            return status.sourcecodeMode;
        }), distinctUntilChanged()).subscribe(b => {
            this.switch(b);
        }));
    }
    onDestroy() {
        this.subs.forEach(i => i.unsubscribe());
    }
    switch(b) {
        this.layout.dashboard.style.display = b ? 'none' : '';
        this.container.style.display = b ? 'block' : 'none';
        if (b) {
            this.btn.classList.add('textbus-status-bar-btn-active');
            this.codeMirrorInstance = codemirror(this.container, {
                lineNumbers: true,
                mode: 'text/html',
                theme: 'textbus',
                indentUnit: 2,
                lineWrapping: true,
                value: pretty(this.editor.getContents().content)
            });
            this.codeMirrorInstance.setOption('readOnly', this.editorController.readonly ? 'nocursor' : false);
        }
        else {
            this.btn.classList.remove('textbus-status-bar-btn-active');
            if (this.codeMirrorInstance) {
                const value = this.codeMirrorInstance.getValue().split('\n').map(i => i.trim()).join('');
                this.editor.setContents(value);
                this.codeMirrorInstance = null;
                this.container.innerHTML = '';
            }
        }
    }
};
SourcecodeModePlugin = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [Layout,
        Editor,
        I18n,
        EditorController])
], SourcecodeModePlugin);
export { SourcecodeModePlugin };
//# sourceMappingURL=sourcecode-mode.plugin.js.map