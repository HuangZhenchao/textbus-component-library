import 'codemirror/mode/htmlmixed/htmlmixed';
import { TBPlugin } from '@textbus/browser';

import {I18n,Layout,Editor,EditorController} from '@textbus/editor'
export declare class SourcecodeModePlugin implements TBPlugin {
    private layout;
    private editor;
    private i18n;
    private editorController;
    private codeMirrorInstance;
    private subs;
    private btn;
    private container;
    constructor(layout: Layout, editor: Editor, i18n: I18n, editorController: EditorController);
    setup(): void;
    onDestroy(): void;
    private switch;
}
