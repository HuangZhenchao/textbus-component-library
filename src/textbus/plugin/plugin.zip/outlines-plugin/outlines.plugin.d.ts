import { Renderer } from '@textbus/core';
import { TBPlugin } from '@textbus/browser';
import { Layout, EditorController, I18n,rootComponent } from '@textbus/editor';
export declare class OutlinesPlugin implements TBPlugin {
    private layout;
    private i18n;
    private rootComponent;
    private editorController;
    private renderer;
    static defaultExpand: boolean;
    private subs;
    private set expand(value);
    private get expand();
    private _expand;
    private btn;
    private btnWrapper;
    private container;
    private links;
    constructor(layout: Layout, i18n: I18n, rootComponent: any, editorController: EditorController, renderer: Renderer);
    setup(): void;
    onDestroy(): void;
    private getTopDistance;
    private getHeadingComponents;
}
