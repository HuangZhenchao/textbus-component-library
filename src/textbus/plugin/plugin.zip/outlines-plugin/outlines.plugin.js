var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var OutlinesPlugin_1;
import { fromEvent } from 'rxjs';
import { sampleTime } from 'rxjs/operators';
import { Injectable, Layout, RootComponent, BackboneAbstractComponent, BranchAbstractComponent, DivisionAbstractComponent, Renderer, createElement, createTextNode, EditorController, I18n } from '@textbus/core';
import { BlockComponent } from '@textbus/components';
let OutlinesPlugin = OutlinesPlugin_1 = class OutlinesPlugin {
    constructor(layout, i18n, rootComponent, editorController, renderer) {
        this.layout = layout;
        this.i18n = i18n;
        this.rootComponent = rootComponent;
        this.editorController = editorController;
        this.renderer = renderer;
        this.subs = [];
        this._expand = false;
        this.container = createElement('div', {
            classes: ['textbus-outlines-plugin'],
            children: [
                createElement('h3', {
                    classes: ['textbus-outlines-plugin-title'],
                    children: [
                        createTextNode(this.i18n.get('plugins.outlines.title'))
                    ]
                }),
                this.links = createElement('div', {
                    classes: ['textbus-outlines-plugin-links']
                })
            ]
        });
        this.btnWrapper = createElement('div', {
            classes: ['textbus-outlines-plugin-btn-wrapper'],
            children: [
                this.btn = createElement('button', {
                    classes: ['textbus-status-bar-btn'],
                    attrs: {
                        type: 'button',
                        title: this.i18n.get('plugins.outlines.switchText')
                    },
                    children: [
                        createElement('span', {
                            classes: ['textbus-icon-tree']
                        })
                    ]
                })
            ]
        });
    }
    set expand(b) {
        this._expand = b;
        if (b) {
            this.btn.classList.add('textbus-status-bar-btn-active');
            this.container.style.display = 'block';
            this.container.style.width = this.layout.dashboard.offsetWidth * 0.2 + 'px';
        }
        else {
            this.btn.classList.remove('textbus-status-bar-btn-active');
            this.container.style.display = 'none';
        }
    }
    get expand() {
        return this._expand;
    }
    setup() {
        this.subs.push(this.renderer.onViewUpdated.pipe(sampleTime(1000)).subscribe(() => {
            const components = this.getHeadingComponents();
            const headingNativeNodes = components.map(component => {
                return this.renderer.getComponentRootNativeNode(component);
            });
            const children = Array.from(this.links.children);
            for (let i = headingNativeNodes.length; i < children.length; i++) {
                this.links.removeChild(children[i]);
            }
            for (let i = 0; i < headingNativeNodes.length; i++) {
                const h = headingNativeNodes[i];
                const child = children[i];
                if (child) {
                    child.className = 'textbus-outlines-plugin-' + h.tagName.toLowerCase();
                    const a = child.querySelector('a');
                    a.onclick = () => {
                        h.getBoundingClientRect();
                        this.layout.scroller.scrollTo({
                            top: this.getTopDistance(h)
                        });
                    };
                    a.innerText = h.innerText;
                }
                else {
                    const a = createElement('a', {
                        attrs: {
                            href: 'javascript:;'
                        },
                        children: [createTextNode(h.innerText)]
                    });
                    a.onclick = () => {
                        h.getBoundingClientRect();
                        this.layout.scroller.scrollTo({
                            top: this.getTopDistance(h)
                        });
                    };
                    const link = createElement('div', {
                        classes: ['textbus-outlines-plugin-' + h.tagName.toLowerCase()],
                        children: [a]
                    });
                    this.links.appendChild(link);
                }
            }
        }), fromEvent(this.btn, 'click').subscribe(() => {
            this.expand = !this.expand && !this.editorController.sourceCodeMode;
        }), this.editorController.onStateChange.subscribe(status => {
            this.btn.disabled = status.sourcecodeMode;
            if (status.sourcecodeMode) {
                this.expand = false;
            }
        }));
        this.layout.leftContainer.appendChild(this.container);
        this.layout.bottomBar.appendChild(this.btnWrapper);
        this.expand = OutlinesPlugin_1.defaultExpand;
    }
    onDestroy() {
        this.subs.forEach(i => i.unsubscribe());
    }
    getTopDistance(el) {
        let i = el.offsetTop;
        while (el.offsetParent) {
            el = el.offsetParent;
            i += el.offsetTop;
        }
        return i;
    }
    getHeadingComponents() {
        const components = [];
        function fn(component, result) {
            if (component instanceof DivisionAbstractComponent) {
                if (component instanceof BlockComponent) {
                    if (/h[1-6]/.test(component.tagName)) {
                        result.push(component);
                    }
                }
                else {
                    component.slot.sliceContents().forEach(i => {
                        if (typeof i === 'string') {
                            return;
                        }
                        fn(i, result);
                    });
                }
            }
            else if (component instanceof BranchAbstractComponent) {
                component.slots.forEach(slot => {
                    slot.sliceContents().forEach((i) => {
                        if (typeof i === 'string') {
                            return;
                        }
                        fn(i, result);
                    });
                });
            }
            else if (component instanceof BackboneAbstractComponent) {
                Array.from(component).forEach(slot => {
                    slot.sliceContents().forEach((i) => {
                        if (typeof i === 'string') {
                            return;
                        }
                        fn(i, result);
                    });
                });
            }
        }
        fn(this.rootComponent, components);
        return components;
    }
};
OutlinesPlugin.defaultExpand = false;
OutlinesPlugin = OutlinesPlugin_1 = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [Layout,
        I18n,
        RootComponent,
        EditorController,
        Renderer])
], OutlinesPlugin);
export { OutlinesPlugin };
//# sourceMappingURL=outlines.plugin.js.map