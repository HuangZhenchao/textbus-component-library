var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Injectable, RootComponent, BrComponent, TBSelection, Renderer } from '@textbus/core';
import { BlockComponent } from '@textbus/components';
let GuardEndBlockPlugin = class GuardEndBlockPlugin {
    constructor(rootComponent, renderer, selection) {
        this.rootComponent = rootComponent;
        this.renderer = renderer;
        this.selection = selection;
        this.subs = [];
    }
    setup() {
        const rootComponent = this.rootComponent;
        const selection = this.selection;
        this.subs.push(this.renderer.onRendingBefore.subscribe(() => {
            const isEmpty = rootComponent.slot.length === 0;
            this.guardLastIsParagraph(rootComponent.slot);
            if (isEmpty && selection.firstRange) {
                const position = selection.firstRange.findFirstPosition(rootComponent.slot);
                selection.firstRange.setStart(position.fragment, position.index);
                selection.firstRange.setEnd(position.fragment, position.index);
            }
        }));
    }
    onDestroy() {
        this.subs.forEach(i => i.unsubscribe());
    }
    guardLastIsParagraph(fragment) {
        const last = fragment.sliceContents(fragment.length - 1)[0];
        if (last instanceof BlockComponent && /^(h[1-6]|div|p)$/i.test(last.tagName)) {
            return;
        }
        const p = new BlockComponent('p');
        p.slot.append(new BrComponent());
        fragment.append(p);
    }
};
GuardEndBlockPlugin = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [RootComponent,
        Renderer,
        TBSelection])
], GuardEndBlockPlugin);
export { GuardEndBlockPlugin };
//# sourceMappingURL=guard-end-block.plugin.js.map