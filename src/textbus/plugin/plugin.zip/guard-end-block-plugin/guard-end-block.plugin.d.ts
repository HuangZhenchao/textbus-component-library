import { TBSelection, Renderer } from '@textbus/core';
import { TBPlugin } from '@textbus/browser';
import { rootComponent } from '@textbus/editor';
export declare class GuardEndBlockPlugin implements TBPlugin {
    private rootComponent;
    private renderer;
    private selection;
    private subs;
    constructor(rootComponent: any, renderer: Renderer, selection: TBSelection);//rootComponent
    setup(): void;
    onDestroy(): void;
    private guardLastIsParagraph;
}
