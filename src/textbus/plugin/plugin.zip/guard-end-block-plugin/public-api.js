export * from './guard-end-block.plugin';
//# sourceMappingURL=public-api.js.map