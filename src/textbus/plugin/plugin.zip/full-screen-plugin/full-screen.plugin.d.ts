import { TBPlugin} from '@textbus/browser';
import {I18n,Layout} from '@textbus/editor'
export declare class FullScreenPlugin implements TBPlugin {
    private layout;
    private i18n;
    set full(b: boolean);
    get full(): boolean;
    private elementRef;
    private btn;
    private icon;
    private _full;
    private subs;
    constructor(layout: Layout, i18n: I18n);
    setup(): void;
    onDestroy(): void;
    private fullScreen;
}
