var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { fromEvent } from 'rxjs';
import { Injectable, Layout, I18n, createElement } from '@textbus/core';
let FullScreenPlugin = class FullScreenPlugin {
    constructor(layout, i18n) {
        this.layout = layout;
        this.i18n = i18n;
        this._full = false;
        this.subs = [];
    }
    set full(b) {
        this._full = b;
        this.fullScreen(b);
        this.icon.className = b ? 'textbus-icon-shrink' : 'textbus-icon-enlarge';
    }
    get full() {
        return this._full;
    }
    setup() {
        this.elementRef = createElement('div', {
            classes: ['textbus-full-screen'],
            children: [
                this.btn = createElement('button', {
                    attrs: {
                        type: 'button',
                        title: this.i18n.get('plugins.fullScreen.switchFullScreen') || '全屏'
                    },
                    classes: ['textbus-status-bar-btn'],
                    children: [
                        this.icon = createElement('span')
                    ]
                })
            ]
        });
        this.subs.push(fromEvent(this.btn, 'click').subscribe(() => {
            this.full = !this.full;
        }));
        this.full = false;
        this.layout.bottomBar.appendChild(this.elementRef);
    }
    onDestroy() {
        this.subs.forEach(s => s.unsubscribe());
    }
    fullScreen(is) {
        is ?
            this.layout.container.classList.add('textbus-container-full-screen') :
            this.layout.container.classList.remove('textbus-container-full-screen');
    }
};
FullScreenPlugin = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [Layout,
        I18n])
], FullScreenPlugin);
export { FullScreenPlugin };
//# sourceMappingURL=full-screen.plugin.js.map