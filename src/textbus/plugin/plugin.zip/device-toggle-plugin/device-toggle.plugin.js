var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
import { fromEvent } from 'rxjs';
import { Inject, Injectable, InjectionToken, Layout, EditorController, I18n, createElement } from '@textbus/core';
export const DEVICE_OPTIONS = new InjectionToken('DEVICE_OPTIONS');
let DeviceTogglePlugin = class DeviceTogglePlugin {
    constructor(options, editorController, i18n, layout) {
        this.options = options;
        this.editorController = editorController;
        this.i18n = i18n;
        this.layout = layout;
        this.menuItems = [];
        this.subs = [];
    }
    setup() {
        this.elementRef = createElement('div', {
            classes: ['textbus-device'],
            children: [
                this.button = createElement('button', {
                    attrs: {
                        type: 'button',
                        title: this.i18n.get('plugins.device.title') || '切换设备'
                    },
                    classes: ['textbus-status-bar-btn', 'textbus-device-btn'],
                    children: [
                        createElement('span', {
                            classes: ['textbus-icon-device']
                        }),
                        this.label = createElement('span', {
                            attrs: {
                                style: 'margin-left: 5px'
                            }
                        })
                    ]
                }),
                this.menus = createElement('div', {
                    classes: ['textbus-device-menus'],
                    children: this.options.map(item => {
                        const option = createElement('button', {
                            attrs: {
                                type: 'button'
                            },
                            props: {
                                innerText: item.label
                            },
                            classes: ['textbus-device-option'],
                            children: [
                                createElement('small', {
                                    props: {
                                        innerText: item.value
                                    }
                                })
                            ]
                        });
                        this.menuItems.push(option);
                        if (item.default) {
                            this.setTabletWidth(item.value);
                        }
                        return option;
                    })
                })
            ]
        });
        let isSelfClick = false;
        this.setDeviceType('PC');
        this.subs.push(fromEvent(this.menus, 'click').subscribe((ev) => {
            const index = this.menuItems.indexOf(ev.target);
            if (index > -1) {
                this.setDeviceType(this.options[index].label);
            }
        }), fromEvent(document, 'click').subscribe(() => {
            if (!isSelfClick) {
                this.elementRef.classList.remove('textbus-device-expand');
            }
            isSelfClick = false;
        }), fromEvent(this.button, 'click').subscribe(() => {
            isSelfClick = true;
            this.elementRef.classList.toggle('textbus-device-expand');
        }), this.editorController.onStateChange.subscribe(status => {
            this.button.disabled = status.readonly || status.sourcecodeMode;
        }));
        this.layout.bottomBar.appendChild(this.elementRef);
    }
    onDestroy() {
        this.subs.forEach(i => i.unsubscribe());
    }
    setDeviceType(name) {
        let flag = false;
        this.options.forEach((item, index) => {
            if (item.label === name) {
                flag = true;
                this.setTabletWidth(item.value);
                this.label.innerText = item.label;
                this.menuItems[index].classList.add('textbus-device-option-active');
            }
            else {
                this.menuItems[index].classList.remove('textbus-device-option-active');
            }
        });
        if (!flag) {
            this.label.innerText = this.i18n.get('plugins.device.unknownDeviceText') || '未知设备';
        }
    }
    setTabletWidth(width) {
        this.layout.scroller.style.padding = (width === '100%' || !width) ? '' : '20px';
        this.layout.pageContainer.style.width = width;
    }
};
DeviceTogglePlugin = __decorate([
    Injectable(),
    __param(0, Inject(DEVICE_OPTIONS)),
    __metadata("design:paramtypes", [Array, EditorController,
        I18n,
        Layout])
], DeviceTogglePlugin);
export { DeviceTogglePlugin };
//# sourceMappingURL=device-toggle.plugin.js.map