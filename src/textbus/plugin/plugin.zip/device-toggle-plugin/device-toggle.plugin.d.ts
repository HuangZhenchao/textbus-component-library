import { InjectionToken, TBPlugin, Layout, EditorController, I18n } from '@textbus/core';
import { TBPlugin } from '@textbus/browser';
import { rootComponent } from '@textbus/editor';
export interface DeviceOption {
    label: string;
    value: string;
    default?: boolean;
}
export declare const DEVICE_OPTIONS: InjectionToken<DeviceOption[]>;
export declare class DeviceTogglePlugin implements TBPlugin {
    private options;
    private editorController;
    private i18n;
    private layout;
    private elementRef;
    private button;
    private label;
    private menus;
    private menuItems;
    private subs;
    constructor(options: DeviceOption[], editorController: EditorController, i18n: I18n, layout: Layout);
    setup(): void;
    onDestroy(): void;
    setDeviceType(name: string): void;
    private setTabletWidth;
}
