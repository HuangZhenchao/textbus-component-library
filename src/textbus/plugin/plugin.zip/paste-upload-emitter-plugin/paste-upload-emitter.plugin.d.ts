import {TBPlugin,Input} from '@textbus/browser'
import {I18n,Layout,FileUploader,Dialog} from '@textbus/editor'
export declare class PasteUploadEmitterPlugin implements TBPlugin {
    private input;
    private i18n;
    private fileUploader;
    private dialog;
    constructor(input: Input, i18n: I18n, fileUploader: FileUploader, dialog: Dialog);
    setup(): void;
}
