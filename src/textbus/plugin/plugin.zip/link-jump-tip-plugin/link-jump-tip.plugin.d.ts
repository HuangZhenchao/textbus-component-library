import { TBSelection,  } from '@textbus/core';
import {TBPlugin} from '@textbus/browser'
import {I18n,Layout} from '@textbus/editor'
export declare class LinkJumpTipPlugin implements TBPlugin {
    private selection;
    private layout;
    private i18n;
    private contentDocument;
    private link;
    private style;
    private subs;
    constructor(selection: TBSelection, layout: Layout, i18n: I18n, contentDocument: Document);
    setup(): void;
    onDestroy(): void;
    private onSelectionChange;
    private getLinkByDOMTree;
}
