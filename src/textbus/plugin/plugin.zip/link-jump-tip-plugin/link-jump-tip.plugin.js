var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
import { Inject, Injectable, TBSelection, EDITABLE_DOCUMENT, Layout, I18n } from '@textbus/core';
const styles = `
.textbus-link-jump-plugin {
  border-radius: 3px;
  position: absolute;
  line-height: 1em;
  font-size: 12px;
  padding: 6px 0;
  width: 46px;
  text-align: center;
  margin-left: -23px;
  margin-top: -30px;
  background-color: #333;
  color: #ddd;
  box-shadow: 0 1px 2px rgba(0,0,0,0.3);
  text-decoration: none;
}
.textbus-link-jump-plugin:hover {
  color: #1296db;
}
.textbus-link-jump-plugin:after {
  content: "";
  position: absolute;
  top: 100%;
  left: 50%;
  border-width: 6px;
  margin-left: -6px;
  border-style: solid;
  border-color: #333 transparent transparent;
  pointer-events: none;
}
`;
let LinkJumpTipPlugin = class LinkJumpTipPlugin {
    constructor(selection, layout, i18n, contentDocument) {
        this.selection = selection;
        this.layout = layout;
        this.i18n = i18n;
        this.contentDocument = contentDocument;
        this.link = document.createElement('a');
        this.style = document.createElement('style');
        this.subs = [];
        this.subs.push(this.selection.onChange.subscribe(() => {
            this.onSelectionChange();
        }));
    }
    setup() {
        this.link.innerText = this.i18n.get('plugins.linkJump.accessLink') || '跳转';
        this.link.target = '_blank';
        this.link.className = 'textbus-link-jump-plugin';
        this.style.innerHTML = styles;
        document.head.appendChild(this.style);
    }
    onDestroy() {
        var _a;
        (_a = this.style.parentNode) === null || _a === void 0 ? void 0 : _a.removeChild(this.style);
        this.subs.forEach(i => i.unsubscribe());
    }
    onSelectionChange() {
        var _a;
        const nativeSelection = this.contentDocument.getSelection();
        const firstNativeRange = nativeSelection.rangeCount ? nativeSelection.getRangeAt(0) : null;
        if (firstNativeRange) {
            const focusNode = firstNativeRange.commonAncestorContainer;
            if (focusNode) {
                const container = (focusNode.nodeType === Node.TEXT_NODE ? focusNode.parentNode : focusNode);
                const linkElement = this.getLinkByDOMTree(container);
                if (linkElement && (linkElement.href || linkElement.dataset.href)) {
                    this.link.href = linkElement.href || linkElement.dataset.href;
                    const rect = this.selection.firstRange.getRangePosition();
                    Object.assign(this.link.style, {
                        left: (rect.left + rect.right) / 2 + 'px',
                        top: rect.top + 'px'
                    });
                    if (!this.link.parentNode) {
                        this.layout.docContainer.appendChild(this.link);
                    }
                    return;
                }
            }
        }
        (_a = this.link.parentNode) === null || _a === void 0 ? void 0 : _a.removeChild(this.link);
    }
    getLinkByDOMTree(node) {
        if (node instanceof HTMLElement) {
            if (node.tagName.toLowerCase() === 'a') {
                return node;
            }
            if (node.parentNode) {
                return this.getLinkByDOMTree(node.parentNode);
            }
        }
        return null;
    }
};
LinkJumpTipPlugin = __decorate([
    Injectable(),
    __param(3, Inject(EDITABLE_DOCUMENT)),
    __metadata("design:paramtypes", [TBSelection,
        Layout,
        I18n,
        Document])
], LinkJumpTipPlugin);
export { LinkJumpTipPlugin };
//# sourceMappingURL=link-jump-tip.plugin.js.map