import { ComponentControlPanelView, ComponentSetter, DivisionAbstractComponent, SingleSlotRenderFn, SlotRenderFn, VElement, I18n } from '@textbus/core';
import { ComponentCreator } from '../component-library.plugin';
export declare class AlertComponentSetter implements ComponentSetter<AlertComponent> {
    private i18n;
    constructor(i18n: I18n);
    create(instance: AlertComponent): ComponentControlPanelView;
}
export declare class AlertComponent extends DivisionAbstractComponent {
    fill: boolean;
    type: string;
    constructor();
    clone(): AlertComponent;
    slotRender(isOutputMode: boolean, singleSlotRendererFn: SingleSlotRenderFn): VElement;
    render(isOutputMode: boolean, slotRendererFn: SlotRenderFn): VElement;
}
export declare const alertComponentExample: ComponentCreator;
