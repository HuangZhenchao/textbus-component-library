import { DivisionAbstractComponent, SlotRenderFn, VElement, SingleSlotRenderFn } from '@textbus/core';
import { ComponentCreator } from '../component-library.plugin';
export interface JumbotronOptions {
    minHeight: string;
    backgroundImage: string;
    backgroundSize: string;
    backgroundPosition: string;
}
export declare class JumbotronComponent extends DivisionAbstractComponent {
    options: JumbotronOptions;
    constructor(options: JumbotronOptions);
    clone(): JumbotronComponent;
    slotRender(isOutputMode: boolean, slotRendererFn: SingleSlotRenderFn): VElement;
    render(isOutputMode: boolean, slotRendererFn: SlotRenderFn): VElement;
}
export declare const jumbotronComponentExample: ComponentCreator;
