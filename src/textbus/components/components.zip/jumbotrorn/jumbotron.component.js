var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var JumbotronComponent_1;
import { Injectable, Component, ComponentSetter, DivisionAbstractComponent, VElement, FileUploader, I18n } from '@textbus/core';
import { BlockComponent } from '@textbus/components';
import { Form, FormTextField } from '@textbus/uikit';
let JumbotronComponentSetter = class JumbotronComponentSetter {
    constructor(uploader, i18n) {
        this.uploader = uploader;
        this.i18n = i18n;
    }
    create(instance) {
        const childI18n = this.i18n.getContext('components.jumbotronComponent.setter');
        const form = new Form({
            mini: true,
            confirmBtnText: childI18n.get('confirmBtnText'),
            items: [
                new FormTextField({
                    name: 'minHeight',
                    value: instance.options.minHeight,
                    placeholder: childI18n.get('minHeightInputPlaceholder'),
                    label: childI18n.get('minHeightLabel')
                }),
                new FormTextField({
                    label: childI18n.get('backgroundImageLabel'),
                    name: 'backgroundImage',
                    placeholder: childI18n.get('backgroundImageInputPlaceholder'),
                    canUpload: true,
                    uploadType: 'image',
                    uploadBtnText: childI18n.get('uploadBtnText'),
                    value: instance.options.backgroundImage,
                    validateFn(value) {
                        if (!value) {
                            return childI18n.get('validateErrorMessage');
                        }
                        return null;
                    }
                })
            ]
        });
        form.setFileUploader(this.uploader);
        form.onComplete.subscribe(map => {
            instance.options.minHeight = map.get('minHeight');
            instance.options.backgroundImage = map.get('backgroundImage');
            instance.slot.markAsDirtied();
        });
        return {
            title: childI18n.get('title'),
            view: form.elementRef
        };
    }
};
JumbotronComponentSetter = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [FileUploader,
        I18n])
], JumbotronComponentSetter);
class JumbotronComponentLoader {
    match(element) {
        return element.nodeName.toLowerCase() === 'tb-jumbotron';
    }
    read(element) {
        const style = element.style;
        const component = new JumbotronComponent({
            backgroundImage: (style.backgroundImage || '').replace(/^url\(['"]?|['"]?\)$/g, ''),
            backgroundSize: style.backgroundSize,
            backgroundPosition: style.backgroundPosition,
            minHeight: style.minHeight
        });
        return {
            component: component,
            slotsMap: [{
                    from: element,
                    toSlot: component.slot
                }]
        };
    }
}
let JumbotronComponent = JumbotronComponent_1 = class JumbotronComponent extends DivisionAbstractComponent {
    constructor(options) {
        super('tb-jumbotron');
        this.options = options;
    }
    clone() {
        const component = new JumbotronComponent_1(Object.assign({}, this.options));
        component.slot.from(this.slot.clone());
        return component;
    }
    slotRender(isOutputMode, slotRendererFn) {
        const vEle = VElement.createElement("tb-jumbotron", { style: {
                backgroundImage: `url("${this.options.backgroundImage}")`,
                backgroundSize: this.options.backgroundSize || 'cover',
                backgroundPosition: this.options.backgroundPosition || 'center',
                minHeight: this.options.minHeight
            } });
        return slotRendererFn(this.slot, vEle);
    }
    render(isOutputMode, slotRendererFn) {
        return slotRendererFn(this.slot);
    }
};
JumbotronComponent = JumbotronComponent_1 = __decorate([
    Component({
        loader: new JumbotronComponentLoader(),
        providers: [{
                provide: ComponentSetter,
                useClass: JumbotronComponentSetter
            }],
        styles: [
            `
tb-jumbotron {
  display: block;
  min-height: 200px;
  margin-bottom: 1em;
  background-color: #eee;
  padding: 20px;
}
`
        ]
    }),
    __metadata("design:paramtypes", [Object])
], JumbotronComponent);
export { JumbotronComponent };
export const jumbotronComponentExample = {
    name: i18n => i18n.get('components.jumbotronComponent.creator.name'),
    category: 'TextBus',
    example: `<img src="data:image/svg+xml;charset=UTF-8,${encodeURIComponent('<svg width="100" height="70" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><defs><linearGradient id="bg" x1="0%" y1="0%" x2="0%" y2="100%"><stop offset="0%" stop-color="#6ad1ec"/><stop offset="100%" stop-color="#fff"/></linearGradient></defs><g><rect fill="url(#bg)" height="100%" width="100%"/></g><path fill="#fff" opacity="0.3" d="M81.25 28.125c0 5.178-4.197 9.375-9.375 9.375s-9.375-4.197-9.375-9.375 4.197-9.375 9.375-9.375 9.375 4.197 9.375 9.375z"></path><path fill="#fff" opacity="0.3"  d="M87.5 81.25h-75v-12.5l21.875-37.5 25 31.25h6.25l21.875-18.75z"></path><text font-family="Helvetica, Arial, sans-serif" font-size="12" x="10" y="25" stroke-width="0.3" stroke="#000" fill="#000000">Hello, world!</text><text font-family="Helvetica, Arial, sans-serif" font-size="6" x="10" y="40" stroke-width="0" stroke="#000" fill="#000000">我是 TextBus 富文本编辑器。</text><text font-family="Helvetica, Arial, sans-serif" font-size="6" x="10" y="50" stroke-width="0" stroke="#000" fill="#000000">别来无恙？</text></svg>')}">`,
    factory(dialog, fileUploader, i18n) {
        const childI18n = i18n.getContext('components.jumbotronComponent.creator.form');
        const form = new Form({
            title: childI18n.get('title'),
            confirmBtnText: childI18n.get('confirmBtnText'),
            cancelBtnText: childI18n.get('cancelBtnText'),
            items: [
                new FormTextField({
                    name: 'minHeight',
                    value: '200px',
                    placeholder: childI18n.get('minHeightInputPlaceholder'),
                    label: childI18n.get('minHeightLabel')
                }),
                new FormTextField({
                    label: childI18n.get('backgroundImageLabel'),
                    name: 'backgroundImage',
                    placeholder: childI18n.get('backgroundImageInputPlaceholder'),
                    canUpload: true,
                    uploadType: 'image',
                    uploadBtnText: childI18n.get('uploadBtnText'),
                    validateFn(value) {
                        if (!value) {
                            return childI18n.get('validateErrorMessage');
                        }
                        return null;
                    }
                })
            ]
        });
        form.setFileUploader(fileUploader);
        return new Promise((resolve) => {
            dialog.dialog(form.elementRef);
            const s = form.onComplete.subscribe(data => {
                const component = new JumbotronComponent({
                    backgroundPosition: 'center center',
                    backgroundSize: 'cover',
                    backgroundImage: data.get('backgroundImage'),
                    minHeight: data.get('minHeight') + ''
                });
                const h1 = new BlockComponent('h1');
                h1.slot.append('Hello, world!');
                const p1 = new BlockComponent('p');
                p1.slot.append('你好，我是 TextBus 富文本编辑器。');
                const p2 = new BlockComponent('p');
                p2.slot.append('你现在还好吗？');
                component.slot.append(h1);
                component.slot.append(p1);
                component.slot.append(p2);
                s.unsubscribe();
                resolve(component);
                dialog.close();
            });
            const b = form.onClose.subscribe(() => {
                s.unsubscribe();
                b.unsubscribe();
                dialog.close();
            });
        });
    }
};
//# sourceMappingURL=jumbotron.component.js.map