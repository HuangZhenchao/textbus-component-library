var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var AlertComponent_1;
import { Injectable, Component, ComponentSetter, DivisionAbstractComponent, VElement, I18n } from '@textbus/core';
import { Form, FormSelect, FormSwitch } from '@textbus/uikit';
class AlertComponentLoader {
    match(element) {
        return element.tagName.toLowerCase() === 'div' && element.classList.contains('tb-alert');
    }
    read(element) {
        const component = new AlertComponent();
        return {
            component,
            slotsMap: [{
                    toSlot: component.slot,
                    from: element
                }]
        };
    }
}
let AlertComponentSetter = class AlertComponentSetter {
    constructor(i18n) {
        this.i18n = i18n;
    }
    create(instance) {
        const childI18n = this.i18n.getContext('components.alertComponent.setter');
        const form = new Form({
            mini: true,
            confirmBtnText: childI18n.get('confirmBtnText'),
            items: [
                new FormSelect({
                    name: 'type',
                    label: childI18n.get('typeLabel'),
                    options: 'default,primary,info,success,warning,danger,dark,gray'.split(',').map(i => {
                        return {
                            label: i,
                            value: i,
                            selected: i === instance.type
                        };
                    })
                }),
                new FormSwitch({
                    label: childI18n.get('fillLabel'),
                    name: 'fill',
                    checked: instance.fill
                })
            ]
        });
        form.onComplete.subscribe(map => {
            instance.fill = map.get('fill');
            instance.type = map.get('type');
            instance.slot.markAsDirtied();
        });
        return {
            title: childI18n.get('title'),
            view: form.elementRef
        };
    }
};
AlertComponentSetter = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [I18n])
], AlertComponentSetter);
export { AlertComponentSetter };
let AlertComponent = AlertComponent_1 = class AlertComponent extends DivisionAbstractComponent {
    constructor() {
        super('div');
        this.fill = false;
        this.type = '';
    }
    clone() {
        const component = new AlertComponent_1();
        component.slot.from(this.slot.clone());
        return component;
    }
    slotRender(isOutputMode, singleSlotRendererFn) {
        const classes = ['tb-alert'];
        if (this.fill) {
            classes.push('tb-alert-fill');
        }
        if (this.type) {
            classes.push('tb-alert-' + this.type);
        }
        return singleSlotRendererFn(this.slot, VElement.createElement("div", { class: classes.join(' ') }));
    }
    render(isOutputMode, slotRendererFn) {
        return slotRendererFn(this.slot);
    }
};
AlertComponent = AlertComponent_1 = __decorate([
    Component({
        loader: new AlertComponentLoader(),
        providers: [{
                provide: ComponentSetter,
                useClass: AlertComponentSetter
            }],
        styles: [`
.tb-alert {
  padding: 10px 15px;
  border-radius: 6px;
  border: 1px solid #e9eaec;
  background-color: #f8f8f9;
  margin-top: 1em;
  margin-bottom: 1em
}

.tb-alert.tb-alert-primary {
  border-color: rgba(18, 150, 219, 0.3);
  background-color: rgba(18, 150, 219, 0.15)
}

.tb-alert.tb-alert-primary.tb-alert-fill {
  color: #fff;
  background-color: #1296db
}

.tb-alert.tb-alert-success {
  border-color: rgba(21, 189, 154, 0.3);
  background-color: rgba(21, 189, 154, 0.15)
}

.tb-alert.tb-alert-success.tb-alert-fill {
  color: #fff;
  background-color: #15bd9a
}

.tb-alert.tb-alert-info {
  border-color: rgba(106, 209, 236, 0.3);
  background-color: rgba(106, 209, 236, 0.15)
}

.tb-alert.tb-alert-info.tb-alert-fill {
  color: #fff;
  background-color: #6ad1ec
}

.tb-alert.tb-alert-warning {
  border-color: rgba(255, 153, 0, 0.3);
  background-color: rgba(255, 153, 0, 0.15)
}

.tb-alert.tb-alert-warning.tb-alert-fill {
  color: #fff;
  background-color: #f90
}

.tb-alert.tb-alert-danger {
  border-color: rgba(231, 79, 94, 0.3);
  background-color: rgba(231, 79, 94, 0.15)
}

.tb-alert.tb-alert-danger.tb-alert-fill {
  color: #fff;
  background-color: #E74F5E
}

.tb-alert.tb-alert-dark {
  border-color: rgba(73, 80, 96, 0.3);
  background-color: rgba(73, 80, 96, 0.15)
}

.tb-alert.tb-alert-dark.tb-alert-fill {
  color: #fff;
  background-color: #495060
}

.tb-alert.tb-alert-gray {
  border-color: rgba(187, 190, 196, 0.3);
  background-color: rgba(187, 190, 196, 0.15)
}

.tb-alert.tb-alert-gray.tb-alert-fill {
  color: #fff;
  background-color: #bbbec4
}

.tb-alert-fill code {
  background-color: rgba(255, 255, 255, 0.2);
  border: none
}`
        ]
    }),
    __metadata("design:paramtypes", [])
], AlertComponent);
export { AlertComponent };
export const alertComponentExample = {
    name: i18n => i18n.get('components.alertComponent.creator.name'),
    category: 'TextBus',
    example: `<img src="data:image/svg+xml;charset=UTF-8,${encodeURIComponent('<svg width="100" height="70" xmlns="http://www.w3.org/2000/svg"><g><rect fill="#fff" height="100%" width="100%"/></g><rect width="90%" height="20" fill="#eee" stroke="#dedede" rx="5" ry="5" x="5" y="25"></rect><text font-family="Helvetica, Arial, sans-serif" font-size="10" x="10" y="35" stroke-width="0" stroke="#000" fill="#000000">文本内容</text></svg>')}">`,
    factory() {
        return new AlertComponent();
    }
};
//# sourceMappingURL=alert.component.js.map