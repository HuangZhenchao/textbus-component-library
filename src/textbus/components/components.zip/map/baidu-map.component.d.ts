import { ImageComponent } from '@textbus/components';
import { ComponentCreator } from '../component-library.plugin';
export declare class BaiduMapComponent extends ImageComponent {
    static ak: string;
    clone(): BaiduMapComponent;
}
export declare const baiduMapComponentExample: ComponentCreator;
