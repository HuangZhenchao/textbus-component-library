import { ComponentControlPanelView, ComponentSetter, LeafAbstractComponent, VElement, I18n } from '@textbus/core';
import { ComponentCreator } from '../component-library.plugin';
export declare class KatexComponentSetter implements ComponentSetter<KatexComponent> {
    private i18n;
    constructor(i18n: I18n);
    create(instance: KatexComponent): ComponentControlPanelView;
}
export declare class KatexComponent extends LeafAbstractComponent {
    source: string;
    block: boolean;
    constructor(source?: string);
    render(): VElement;
    clone(): KatexComponent;
}
export declare const katexComponentExample: ComponentCreator;
