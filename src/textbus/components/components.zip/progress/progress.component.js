var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var ProgressComponent_1;
import { Component, LeafAbstractComponent, VElement } from '@textbus/core';
import { Form, FormTextField, FormSelect } from '@textbus/uikit';
class ProgressComponentLoader {
    match(element) {
        return element.nodeName.toLowerCase() === 'tb-progress';
    }
    read(element) {
        const component = new ProgressComponent({
            type: element.getAttribute('type'),
            progress: +element.getAttribute('progress') || 0,
            max: +element.getAttribute('max') || 100,
            min: +element.getAttribute('min') || 0
        });
        return {
            slotsMap: [],
            component
        };
    }
}
const colors = {
    primary: '#1296db',
    info: '#6ad1ec',
    success: '#15bd9a',
    warning: '#ff9900',
    danger: '#E74F5E',
    dark: '#495060',
    gray: '#bbbec4'
};
let ProgressComponent = ProgressComponent_1 = class ProgressComponent extends LeafAbstractComponent {
    constructor(config) {
        super('tb-progress');
        this.config = config;
        this.block = true;
    }
    clone() {
        return new ProgressComponent_1(Object.assign({}, this.config));
    }
    render() {
        const config = this.config;
        const value = Math.round((config.progress - config.min) / (config.max - config.min) * 100) + '%';
        return (VElement.createElement("tb-progress", Object.assign({}, config),
            VElement.createElement("span", { class: "tb-progress-min" }, config.min),
            VElement.createElement("div", { style: { width: value } },
                VElement.createElement("span", { class: "tb-progress-value" }, value)),
            VElement.createElement("span", { class: "tb-progress-max" }, config.max)));
    }
};
ProgressComponent = ProgressComponent_1 = __decorate([
    Component({
        loader: new ProgressComponentLoader(),
        styles: [
            `
tb-progress {
  margin: 2em 0 1em;
  background-color: #eee;
  border-radius: 3px;
  height: 6px;
  display: block;
  position: relative;
}
tb-progress > div {
  height: 100%;
  border-radius: inherit;
  background-color: #aaa;
  position: relative;
}
tb-progress > span {
  position: absolute;
  bottom: 100%;
  font-size:12px;
}
.tb-progress-value {
  position: absolute;
  right: 0;
  bottom: 100%;
  background-color: #000;
  color: #fff;
  padding: 3px 8px;
  border-radius: 5px;
  font-size: 13px;
  transform: translateX(50%) translateY(-4px);
}
.tb-progress-value:after {
  content: "";
  position: absolute;
  top: 100%;
  left: 50%;
  margin-left: -4px;
  width: 0;
  height: 0;
  border-width: 4px;
  border-style: solid;
  border-color: #000 transparent transparent;
}
.tb-progress-min {
  left: 0;
}
.tb-progress-max {
  right: 0;
}
tb-progress[type=primary] > div {
  background-color: ${colors.primary}
}
tb-progress[type=info] > div {
  background-color: ${colors.info}
}
tb-progress[type=success] > div {
  background-color: ${colors.success}
}
tb-progress[type=warning] > div {
  background-color: ${colors.warning}
}
tb-progress[type=danger] > div {
  background-color: ${colors.danger}
}
tb-progress[type=dark] > div {
  background-color: ${colors.dark}
}
tb-progress[type=gray] > div {
  background-color: ${colors.gray}
}
`
        ]
    }),
    __metadata("design:paramtypes", [Object])
], ProgressComponent);
export { ProgressComponent };
export const progressComponentExample = {
    name: i18n => i18n.get('components.progressComponent.creator.name'),
    category: 'TextBus',
    example: `<img src="data:image/svg+xml;charset=UTF-8,${encodeURIComponent('<svg width="100" height="70" xmlns="http://www.w3.org/2000/svg"><g><rect fill="#fff" height="100%" width="100%"/></g><line x1="10" y1="40" x2="90" y2="40" stroke="#ddd" stroke-width="4" stroke-linecap="round"></line><line x1="10" y1="40" x2="50" y2="40" stroke="#1296db" stroke-width="4" stroke-linecap="round"></line><text font-family="Helvetica, Arial, sans-serif" font-size="10" x="42" y="35" stroke-width="0" stroke="#000" fill="#000000">50%</text></svg>')}">`,
    factory(dialog, _, i18n) {
        const childI18n = i18n.getContext('components.progressComponent.creator.form');
        const form = new Form({
            title: childI18n.get('title'),
            confirmBtnText: childI18n.get('confirmBtnText'),
            cancelBtnText: childI18n.get('cancelBtnText'),
            items: [
                new FormTextField({
                    label: childI18n.get('max.label'),
                    name: 'max',
                    value: '100',
                    placeholder: childI18n.get('max.placeholder'),
                    validateFn(value) {
                        if (!value) {
                            return childI18n.get('max.validateErrorMessage');
                        }
                        return null;
                    }
                }),
                new FormTextField({
                    label: childI18n.get('min.label'),
                    name: 'min',
                    value: '0',
                    placeholder: childI18n.get('min.placeholder'),
                    validateFn(value) {
                        if (!value) {
                            return childI18n.get('min.validateErrorMessage');
                        }
                        return null;
                    }
                }),
                new FormTextField({
                    label: childI18n.get('progress.label'),
                    name: 'progress',
                    value: '50',
                    placeholder: childI18n.get('progress.placeholder'),
                    validateFn(value) {
                        if (!value) {
                            return childI18n.get('progress.validateErrorMessage');
                        }
                        return null;
                    }
                }),
                new FormSelect({
                    label: childI18n.get('type.label'),
                    name: 'type',
                    options: [{
                            label: 'Primary',
                            value: 'primary'
                        }, {
                            label: 'Info',
                            value: 'info'
                        }, {
                            label: 'Success',
                            value: 'success'
                        }, {
                            label: 'Warning',
                            value: 'warning'
                        }, {
                            label: 'Danger',
                            value: 'danger'
                        }, {
                            label: 'Dark',
                            value: 'dark'
                        }, {
                            label: 'Gray',
                            value: 'gray'
                        }],
                    validateFn(value) {
                        if (!value) {
                            return childI18n.get('type.validateErrorMessage');
                        }
                        return null;
                    }
                })
            ]
        });
        return new Promise((resolve) => {
            dialog.dialog(form.elementRef);
            const s = form.onComplete.subscribe(data => {
                s.unsubscribe();
                const component = new ProgressComponent({
                    type: data.get('type'),
                    max: +data.get('max'),
                    min: +data.get('min'),
                    progress: +data.get('progress')
                });
                dialog.close();
                resolve(component);
            });
            const b = form.onClose.subscribe(() => {
                s.unsubscribe();
                b.unsubscribe();
                dialog.close();
            });
        });
    }
};
//# sourceMappingURL=progress.component.js.map