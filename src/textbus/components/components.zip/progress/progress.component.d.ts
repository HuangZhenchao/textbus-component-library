import { LeafAbstractComponent, VElement } from '@textbus/core';
import { ComponentCreator } from '../component-library.plugin';
export interface ProgressConfig {
    type: 'primary' | 'info' | 'success' | 'warning' | 'danger' | 'gray' | 'dark';
    progress: number;
    max: number;
    min: number;
}
export declare class ProgressComponent extends LeafAbstractComponent {
    private config;
    block: boolean;
    constructor(config: ProgressConfig);
    clone(): ProgressComponent;
    render(): VElement;
}
export declare const progressComponentExample: ComponentCreator;
