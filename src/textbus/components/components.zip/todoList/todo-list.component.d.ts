import { BranchAbstractComponent, Fragment, VElement, SlotRenderFn, SingleSlotRenderFn } from '@textbus/core';
import { ComponentCreator } from '../component-library.plugin';
declare class TodoListFragment extends Fragment {
    active: boolean;
    disabled: boolean;
    constructor(active: boolean, disabled: boolean);
}
export declare class TodoListComponent extends BranchAbstractComponent<TodoListFragment> {
    listConfigs: TodoListFragment[];
    private stateCollection;
    constructor(listConfigs: TodoListFragment[]);
    slotRender(slot: TodoListFragment, isOutputMode: boolean, slotRendererFn: SingleSlotRenderFn): VElement;
    render(isOutputMode: boolean, slotRendererFn: SlotRenderFn): VElement;
    clone(): TodoListComponent;
    private renderItem;
    private getStateIndex;
}
export declare const todoListComponentExample: ComponentCreator;
export {};
