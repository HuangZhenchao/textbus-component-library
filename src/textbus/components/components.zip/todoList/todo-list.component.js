var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var TodoListComponent_1;
import { Injectable, BranchAbstractComponent, Fragment, VElement, BrComponent, Component, Interceptor, TBSelection, } from '@textbus/core';
import { BlockComponent } from '@textbus/components';
class TodoListFragment extends Fragment {
    constructor(active, disabled) {
        super();
        this.active = active;
        this.disabled = disabled;
    }
}
class TodoListComponentLoader {
    match(element) {
        return element.nodeName.toLowerCase() === 'tb-todo-list';
    }
    read(element) {
        const listConfig = Array.from(element.children).map(child => {
            const stateElement = child.querySelector('.tb-todo-list-state');
            return {
                childSlot: child.querySelector('.tb-todo-list-content'),
                slot: new TodoListFragment(stateElement === null || stateElement === void 0 ? void 0 : stateElement.classList.contains('tb-todo-list-state-active'), stateElement === null || stateElement === void 0 ? void 0 : stateElement.classList.contains('tb-todo-list-state-disabled'))
            };
        });
        const component = new TodoListComponent(listConfig.map(i => i.slot));
        return {
            component: component,
            slotsMap: listConfig.map(i => {
                return {
                    toSlot: i.slot,
                    from: i.childSlot
                };
            })
        };
    }
}
let TodoListComponentInterceptor = class TodoListComponentInterceptor {
    constructor(selection) {
        this.selection = selection;
    }
    onEnter(event) {
        const component = event.instance;
        event.stopPropagation();
        const firstRange = this.selection.firstRange;
        const slot = this.selection.commonAncestorFragment;
        const index = component.slots.indexOf(slot);
        if (slot === component.slots[component.slots.length - 1] && index !== 0) {
            const lastContent = slot.getContentAtIndex(slot.length - 1);
            if (slot.length === 0 ||
                slot.length === 1 && lastContent instanceof BrComponent) {
                component.slots.pop();
                const parentFragment = component.parentFragment;
                const p = new BlockComponent('p');
                p.slot.append(new BrComponent());
                parentFragment.insertAfter(p, component);
                firstRange.setStart(p.slot, 0);
                firstRange.collapse();
                return;
            }
        }
        const next = new TodoListFragment(slot.active, slot.disabled);
        next.from(BlockComponent.breakingLine(slot, firstRange.startIndex));
        component.slots.splice(index + 1, 0, next);
        firstRange.setPosition(next, 0);
    }
};
TodoListComponentInterceptor = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [TBSelection])
], TodoListComponentInterceptor);
let TodoListComponent = TodoListComponent_1 = class TodoListComponent extends BranchAbstractComponent {
    constructor(listConfigs) {
        super('tb-todo-list');
        this.listConfigs = listConfigs;
        this.stateCollection = [{
                active: false,
                disabled: false
            }, {
                active: true,
                disabled: false
            }, {
                active: false,
                disabled: true
            }, {
                active: true,
                disabled: true
            }];
        this.slots.push(...listConfigs);
    }
    slotRender(slot, isOutputMode, slotRendererFn) {
        const { host, container } = this.renderItem(slot);
        slotRendererFn(slot, container);
        return host;
    }
    render(isOutputMode, slotRendererFn) {
        return new VElement('tb-todo-list', {
            childNodes: this.slots.map(slot => {
                return slotRendererFn(slot);
            })
        });
    }
    clone() {
        const configs = this.slots.map(i => {
            return i.clone();
        });
        return new TodoListComponent_1(configs);
    }
    renderItem(slot) {
        const state = ['tb-todo-list-state'];
        if (slot.active) {
            state.push('tb-todo-list-state-active');
        }
        if (slot.disabled) {
            state.push('tb-todo-list-state-disabled');
        }
        const content = VElement.createElement("div", { class: "tb-todo-list-content" });
        const item = (VElement.createElement("div", { class: "tb-todo-list-item" },
            VElement.createElement("div", { class: "tb-todo-list-btn" },
                VElement.createElement("div", { class: state.join(' '), onClick: () => {
                        const i = (this.getStateIndex(slot.active, slot.disabled) + 1) % 4;
                        const newState = this.stateCollection[i];
                        slot.active = newState.active;
                        slot.disabled = newState.disabled;
                        slot.markAsDirtied();
                    } })),
            content));
        return {
            host: item,
            container: content
        };
    }
    getStateIndex(active, disabled) {
        for (let i = 0; i < 4; i++) {
            const item = this.stateCollection[i];
            if (item.active === active && item.disabled === disabled) {
                return i;
            }
        }
        return -1;
    }
};
TodoListComponent = TodoListComponent_1 = __decorate([
    Component({
        loader: new TodoListComponentLoader(),
        providers: [{
                provide: Interceptor,
                useClass: TodoListComponentInterceptor
            }],
        styles: [
            `
tb-todo-list {
  display: block;
  margin-top: 1em;
  margin-bottom: 1em;
}
.tb-todo-list-item {
  padding-top: 0.2em;
  padding-bottom: 0.2em;
  display: flex;
}
.tb-todo-list-btn {
  margin-right: 0.6em;
}
.tb-todo-list-state {
  display: inline-block;
  margin-top: 3px;
  width: 12px;
  height: 12px;
  border: 2px solid #1296db;
  background: #fff;
  border-radius: 3px;
  cursor: pointer;
  position: relative;
}
.tb-todo-list-state:after {
  content: "";
  position: absolute;
  border-right: 2px solid #fff;
  border-bottom: 2px solid #fff;
  left: 3px;
  top: 1px;
  width: 4px;
  height: 6px;
  transform: rotateZ(45deg);
}
.tb-todo-list-state-active:after {
  border-color: #1296db;
}
.tb-todo-list-state-disabled {
  opacity: 0.5;
}
.tb-todo-list-content {
  flex: 1;
}
`
        ]
    }),
    __metadata("design:paramtypes", [Array])
], TodoListComponent);
export { TodoListComponent };
export const todoListComponentExample = {
    name: i18n => i18n.get('components.todoListComponent.creator.name'),
    category: 'TextBus',
    example: `<img alt="默认图片" src="data:image/svg+xml;charset=UTF-8,${encodeURIComponent('<svg width="100" height="70" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" ><g><rect fill="#fff" height="100%" width="100%"/></g><defs><g id="item"><rect fill="#fff" stroke="#1296db" height="8" width="8" rx="2" x="15" y="12"/><text font-family="Helvetica, Arial, sans-serif" font-size="8" x="28" y="19"  stroke-width="0" stroke="#000" fill="#000000">待办事项...</text></g></defs><use xlink:href="#item"></use><use xlink:href="#item" transform="translate(0, 12)"></use><use xlink:href="#item" transform="translate(0, 24)"></use><use xlink:href="#item" transform="translate(0, 36)"></use></svg>')}">`,
    factory() {
        const fragment = new TodoListFragment(false, false);
        fragment.append('待办事项...');
        return new TodoListComponent([fragment]);
    }
};
//# sourceMappingURL=todo-list.component.js.map