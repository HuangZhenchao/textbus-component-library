import { BackboneAbstractComponent, ComponentControlPanelView, ComponentSetter, Fragment, SingleSlotRenderFn, SlotRenderFn, VElement, I18n } from '@textbus/core';
import { ComponentCreator } from '../component-library.plugin';
export interface WordExplainParams {
    title: Fragment;
    subtitle: Fragment;
    detail: Fragment;
}
export declare class WordExplainComponentSetter implements ComponentSetter<WordExplainComponent> {
    private i18n;
    constructor(i18n: I18n);
    create(instance: WordExplainComponent): ComponentControlPanelView;
}
export declare class WordExplainComponent extends BackboneAbstractComponent {
    private params;
    width: string;
    private readonly title;
    private readonly subtitle;
    private readonly detail;
    private emptyFragments;
    constructor(params: WordExplainParams);
    canDelete(slot: Fragment): boolean;
    clone(): WordExplainComponent;
    slotRender(slot: Fragment, isOutputMode: boolean, slotRendererFn: SingleSlotRenderFn): VElement;
    render(isOutputMode: boolean, slotRenderFn: SlotRenderFn): VElement;
}
export declare const wordExplainComponentExample: ComponentCreator;
