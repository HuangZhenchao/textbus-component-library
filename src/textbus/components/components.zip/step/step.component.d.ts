import { BranchAbstractComponent, Fragment, SingleSlotRenderFn, SlotRenderFn, VElement } from '@textbus/core';
import { ComponentCreator } from '../component-library.plugin';
export declare class StepComponent extends BranchAbstractComponent {
    private step;
    constructor(slots: Fragment[], step: number);
    clone(): StepComponent;
    slotRender(slot: Fragment, isOutputMode: boolean, slotRendererFn: SingleSlotRenderFn): VElement;
    render(isOutputMode: boolean, slotRendererFn: SlotRenderFn): VElement;
    private renderItem;
}
export declare const stepsComponentExample: ComponentCreator;
