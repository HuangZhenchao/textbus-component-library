import { BranchAbstractComponent, Fragment, SingleSlotRenderFn, SlotRenderFn, VElement } from '@textbus/core';
import { ComponentCreator } from '../component-library.plugin';
export declare type TimelineType = 'primary' | 'info' | 'success' | 'warning' | 'danger' | 'dark' | 'gray';
declare class TimelineFragment extends Fragment {
    type: TimelineType;
    constructor(type: TimelineType);
    clone(): TimelineFragment;
}
export declare class TimelineComponent extends BranchAbstractComponent<TimelineFragment> {
    constructor(list: TimelineFragment[]);
    clone(): TimelineComponent;
    slotRender(slot: TimelineFragment, isOutputMode: boolean, slotRendererFn: SingleSlotRenderFn): VElement;
    render(isOutputMode: boolean, slotRendererFn: SlotRenderFn): VElement;
    private renderItem;
}
export declare const timelineComponentExample: ComponentCreator;
export {};
